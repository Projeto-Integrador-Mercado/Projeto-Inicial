# Protótipos de Desenvolvimento Web — primeira entrega

Mercadinho Silva Camargo • controle de entrada e saída de produtos.

Abra `index.html` no navegador. Qualquer usuário e senha não vazios permitem navegar para a tela de produtos; isso é somente uma demonstração de interface. Não utilize credenciais reais.

## Conteúdo

- `index.html`: tela de login, campos obrigatórios e navegação demonstrativa.
- `produtos.html`: desenho da listagem, pesquisa, cadastro, edição, exclusão e movimentação.
- `estilos.css`: apresentação e adaptação a telas menores.

As ações de produtos apenas exibem um aviso. Não há autenticação, persistência, CRUD ou backend implementados neste pacote. Os saldos são fictícios. O documento descreve os requisitos a desenvolver, não funcionalidades já concluídas.

## Próxima implementação pela equipe

Implementar CRUD de produtos, pesquisa, validações, movimentações e persistência local em JSON/localStorage para a versão didática de DWEB. Bloquear exclusão de produtos com histórico e saída acima do saldo. Tratar dados inválidos e falhas de gravação. Integrar autenticação e backend em etapa própria do PI antes de uso real.

Verificação esperada: cadastrar produto com saldo zero; entrada de 10; saída de 3; saldo 7; recarregar e manter dados. Recusar saída de 8 sem alterar saldo ou histórico. Testar edição, código duplicado, pesquisa, exclusão sem histórico e cancelamento.

O enunciado exige autoria e compreensão do código pelos alunos. Estes arquivos são material de apoio para revisão, adaptação e implementação pela equipe, e não representam o projeto final pronto.

## Entregas

Documento inicial: 25/10/2026 às 23h59. Projeto final: 09/11/2026 às 23h59. Conforme enunciado, o código final deverá estar em `ProjetoFinal` dentro do repositório `DWEB`, acompanhado da URL da aplicação hospedada. Este pacote fica no `Projeto-Inicial` para documentação do PI.
